@interface iOSVibrate : NSObject
{
    NSString *VarPath;
}

-(double)iOSVibrateWeak;
-(double)iOSVibrateStrong;
-(double)iOSVibrateDouble;
-(double)iOSVibrateTriple;

@end
